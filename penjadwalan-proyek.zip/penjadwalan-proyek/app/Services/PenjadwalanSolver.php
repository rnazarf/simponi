<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Process;

/**
 * Jembatan Laravel <-> solver OR-Tools (folder /solver di root proyek).
 *
 *   ekspor tabel -> input.json -> python solver.py -> output.json -> impor ke tabel jadwal
 *
 * Letakkan di app/Services/PenjadwalanSolver.php. Hanya memakai DB facade, jadi tidak bergantung pada model baru.
 * Python opsional lewat config/services.php:  'solver' => ['python' => env('SOLVER_PYTHON', 'python3')]
 *
 * Membuat draf lalu menjalankan (mis. di controller):
 *   $id = DB::table('versi_jadwal')->insertGetId([
 *       'tahun_ajaran_id' => $ta->id, 'nama' => 'Draf '.now()->format('d M H:i'), 'status' => 'draf', 'sumber' => 'solver',
 *       'status_solver' => 'menunggu', 'dibuat_oleh' => auth()->id(), 'created_at' => now(), 'updated_at' => now()]);
 *   JalankanSolverPenjadwalan::dispatch($id);
 */
class PenjadwalanSolver
{
    public function jalankan(int $versiId): void
    {
        $versi = DB::table('versi_jadwal')->find($versiId);
        abort_if(! $versi, 404, 'Versi jadwal tidak ditemukan');
        $this->tandai($versiId, 'berjalan');

        $dir = storage_path("app/solver/$versiId");
        File::ensureDirectoryExists($dir);
        $in = "$dir/input.json";
        $out = "$dir/output.json";
        @unlink($out);
        file_put_contents($in, json_encode($this->ekspor($versi), JSON_UNESCAPED_UNICODE));

        $proses = Process::timeout(900)->path(base_path('solver'))
            ->run([config('services.solver.python', 'python3'), 'solver.py', $in, $out]);

        $hasil = is_file($out) ? json_decode(file_get_contents($out), true) : null;
        if (! $hasil || empty($hasil['jadwal'])) {
            $this->tandai($versiId, 'gagal', [
                'status' => $hasil['status'] ?? 'TIDAK_ADA_OUTPUT',
                'pelanggaran_keras' => array_slice($hasil['pelanggaran_keras'] ?? [], 0, 20),
                'galat' => mb_substr($proses->errorOutput(), -2000),
            ]);
            return;
        }
        $this->impor($versi, $hasil);
    }

    /** Data masukan solver: hanya jam KBM, beban ajar tahun ajaran ini, ketersediaan guru, dan blok terkunci versi aktif. */
    private function ekspor(object $versi): array
    {
        $ta = $versi->tahun_ajaran_id;

        $slots = DB::table('slot_waktu')->where('tahun_ajaran_id', $ta)->where('jenis', 'kbm')->whereNotNull('jam_ke')
            ->get(['hari', 'jam_ke'])->map(fn ($s) => [(int) $s->hari, (int) $s->jam_ke])->all();

        $beban = DB::table('beban_ajar as b')->join('ruang as r', 'r.id', '=', 'b.ruang_id')
            ->where('r.tahun_ajaran_id', $ta)
            ->get(['b.ruang_id', 'r.kelas_id', 'b.guru_id', 'b.jam_per_minggu', 'b.pola_blok'])
            ->map(fn ($b) => [
                'ruang_id' => $b->ruang_id, 'kelas_id' => $b->kelas_id, 'guru_id' => $b->guru_id,
                'jam_per_minggu' => (int) $b->jam_per_minggu, 'pola_blok' => json_decode($b->pola_blok ?? 'null', true),
            ])->all();

        $ketersediaan = DB::table('ketersediaan_guru as k')->join('slot_waktu as s', 's.id', '=', 'k.slot_waktu_id')
            ->where('s.tahun_ajaran_id', $ta)->whereNotNull('s.jam_ke')
            ->get(['k.guru_id', 's.hari', 's.jam_ke', 'k.status'])
            ->map(fn ($k) => ['guru_id' => $k->guru_id, 'hari' => (int) $k->hari, 'jam_ke' => (int) $k->jam_ke, 'status' => $k->status])->all();

        // Blok dikunci diambil dari jadwal aktif (guru_id null = pengampu utama ruang)
        $aktif = DB::table('versi_jadwal')->where('tahun_ajaran_id', $ta)->where('status', 'aktif')->where('id', '!=', $versi->id)->value('id');
        $terkunci = $aktif ? DB::table('jadwal as j')->join('ruang as r', 'r.id', '=', 'j.ruang_id')
            ->where('j.versi_jadwal_id', $aktif)->where('j.dikunci', true)
            ->get(['j.ruang_id', DB::raw('COALESCE(j.guru_id, r.guru_id) as guru_id'), 'j.hari', 'j.jam_ke_mulai', 'j.jam_ke_selesai'])
            ->map(fn ($j) => (array) $j)->all() : [];

        return ['slots' => $slots, 'beban' => $beban, 'ketersediaan' => $ketersediaan, 'terkunci' => $terkunci,
            'pengaturan' => ['batas_waktu_detik' => 120, 'workers' => 8]];
    }

    private function impor(object $versi, array $hasil): void
    {
        $slot = DB::table('slot_waktu')->where('tahun_ajaran_id', $versi->tahun_ajaran_id)->where('jenis', 'kbm')->whereNotNull('jam_ke')->get()
            ->groupBy('hari')->map(fn ($g) => $g->keyBy('jam_ke'));

        DB::transaction(function () use ($versi, $hasil, $slot) {
            DB::table('jadwal')->where('versi_jadwal_id', $versi->id)->delete();
            $baris = [];
            foreach ($hasil['jadwal'] as $b) {
                $baris[] = [
                    'versi_jadwal_id' => $versi->id, 'ruang_id' => $b['ruang_id'], 'guru_id' => $b['guru_id'], 'hari' => $b['hari'],
                    'jam_ke_mulai' => $b['jam_ke_mulai'], 'jam_ke_selesai' => $b['jam_ke_selesai'],
                    'jam_mulai' => $slot[$b['hari']][$b['jam_ke_mulai']]->jam_mulai,
                    'jam_selesai' => $slot[$b['hari']][$b['jam_ke_selesai']]->jam_selesai,
                    'dikunci' => (bool) ($b['dikunci'] ?? false), 'created_at' => now(), 'updated_at' => now(),
                ];
            }
            foreach (array_chunk($baris, 200) as $potong) {
                DB::table('jadwal')->insert($potong);
            }
            $this->tandai($versi->id, 'selesai', [
                'status' => $hasil['status'], 'waktu_detik' => $hasil['waktu_detik'], 'objektif' => $hasil['objektif'] ?? null,
                'batas_bawah' => $hasil['batas_bawah'] ?? null, 'metrik' => $hasil['metrik'] ?? [],
                'pelanggaran_keras' => $hasil['pelanggaran_keras'] ?? [], 'peringatan' => $hasil['peringatan'] ?? [],
            ]);
        });
    }

    /** Jadikan satu versi sebagai jadwal aktif; yang aktif sebelumnya diarsipkan (aturan: satu aktif per tahun ajaran). */
    public function aktifkan(int $versiId): void
    {
        $v = DB::table('versi_jadwal')->find($versiId);
        DB::transaction(function () use ($v) {
            DB::table('versi_jadwal')->where('tahun_ajaran_id', $v->tahun_ajaran_id)->where('status', 'aktif')->update(['status' => 'arsip']);
            DB::table('versi_jadwal')->where('id', $v->id)->update(['status' => 'aktif', 'updated_at' => now()]);
        });
    }

    private function tandai(int $id, string $status, ?array $ringkasan = null): void
    {
        $data = ['status_solver' => $status, 'updated_at' => now()];
        if ($ringkasan !== null) {
            $data['hasil_solver'] = json_encode($ringkasan, JSON_UNESCAPED_UNICODE);
        }
        DB::table('versi_jadwal')->where('id', $id)->update($data);
    }
}
