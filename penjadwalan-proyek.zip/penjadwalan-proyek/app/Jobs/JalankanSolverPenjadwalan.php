<?php

namespace App\Jobs;

use App\Services\PenjadwalanSolver;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\DB;

/** app/Jobs/JalankanSolverPenjadwalan.php. Jalankan worker: php artisan queue:work --timeout=1000 */
class JalankanSolverPenjadwalan implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable;

    public int $timeout = 1000;
    public int $tries = 1;

    public function __construct(public int $versiId)
    {
    }

    public function handle(PenjadwalanSolver $solver): void
    {
        $solver->jalankan($this->versiId);
    }

    public function failed(\Throwable $e): void
    {
        DB::table('versi_jadwal')->where('id', $this->versiId)->update([
            'status_solver' => 'gagal', 'hasil_solver' => json_encode(['galat' => mb_substr($e->getMessage(), 0, 1000)]), 'updated_at' => now(),
        ]);
    }
}
